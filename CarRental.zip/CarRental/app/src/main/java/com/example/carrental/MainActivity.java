package com.example.carrental;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    public static String Cars[]={"Lamborghini","Rolls-Royce","BMW","Mercedes"};
    public static ArrayList<Car>carlist=new ArrayList<>();
    public static ArrayList<String>temp=new ArrayList<>();
    Spinner sp1,sp2;
    TextView rate,millage,days,total;
    RadioButton less,medium,high;
    CheckBox navigator,childSeat,bikeRake;
    Button ok,clr;
    ImageView cImage;
    public static double originalPrice=0.0;
    public static double total1=0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillData();
        sp1=findViewById(R.id.sp1);
        sp2=findViewById(R.id.sp2);
        rate=findViewById(R.id.tvRate);
        millage=findViewById(R.id.tvMillage);
        days=findViewById(R.id.tvDays);
        total=findViewById(R.id.tvTotal);
        less=findViewById(R.id.rbLess);
        medium=findViewById(R.id.rbMedium);
        high=findViewById(R.id.rbHigh);
        navigator=findViewById(R.id.cbNevigator);
        childSeat=findViewById(R.id.cbChildSeat);
        bikeRake=findViewById(R.id.cbBikeRake);
        ok=findViewById(R.id.btnOk);
        clr=findViewById(R.id.btnClr);
        cImage=findViewById(R.id.imgCar);

        //fill the items in the first spinner
        ArrayAdapter aa1 = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,Cars);
        sp1.setAdapter(aa1);

        //make the spinners as the listener
        sp1.setOnItemSelectedListener(new SpinnerEvents());
        sp2.setOnItemSelectedListener(new SpinnerEvents());

        //set the radio button listener
        less.setOnClickListener(new RadioButtonEvents());
        medium.setOnClickListener(new RadioButtonEvents());
        high.setOnClickListener(new RadioButtonEvents());

        bikeRake.setOnCheckedChangeListener(new CheckBoxEvents());
        childSeat.setOnCheckedChangeListener(new CheckBoxEvents());
        navigator.setOnCheckedChangeListener(new CheckBoxEvents());

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double pr=Double.parseDouble(rate.getText().toString());
                int day=Integer.parseInt(days.getText().toString());
                total1 += pr*day*1.13;
                total.setText(String.format("%.2f",total1));
            }
        });
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearChoices();
                sp1.setSelection(0);
                sp2.setSelection(0);
                rate.setText("");
                millage.setText("");
                days.setText("");
                total.setText("");
            }
        });

    }


    //Spinner events
    private class SpinnerEvents implements AdapterView.OnItemSelectedListener{

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            //clearChoices();
            if(parent.getId()==R.id.sp1)
            {
                temp.clear(); //remove all items from the temp list
                fillTemp(Cars[position]); //fill teh temp list upon the selected brands
                ArrayAdapter aa2 = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item,temp);
                sp2.setAdapter(aa2);
            }
            else
            {
                //get the car object
                Car obj=getCarObject(temp.get(position));
                rate.setText(String.valueOf(obj.getRate()));
                millage.setText(String.valueOf(obj.getMillage()));
                originalPrice=obj.getRate();
                //to use an image we need the image id
                // to get the image id we use the image name
                //this method we call to get the image id
                int imgId=getResources().getIdentifier(obj.getImg(),"mipmap",getPackageName());
                //show the img using id
                cImage.setImageResource(imgId);
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            if(parent.getId()==R.id.sp1)
                fillTemp(Cars[0]);
        }
    }

    // private class for radio button implementation
    private class RadioButtonEvents implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            double pr=originalPrice;
            switch(v.getId()){
                case R.id.rbLess:
                    pr=originalPrice+30;
                    if(navigator.isChecked())
                        pr+=5;
                    if(childSeat.isChecked())
                        pr+=7;
                    if(bikeRake.isChecked())
                        pr+=10;
                    rate.setText(String.valueOf(pr));
                    break;
                case R.id.rbMedium:
                    pr=originalPrice+17;
                    if(navigator.isChecked())
                        pr+=5;
                    if(childSeat.isChecked())
                        pr+=7;
                    if(bikeRake.isChecked())
                        pr+=10;
                    rate.setText(String.valueOf(pr));
                    break;
                case R.id.rbHigh:
                    pr=originalPrice+22;
                    if(navigator.isChecked())
                        pr+=5;
                    if(childSeat.isChecked())
                        pr+=7;
                    if(bikeRake.isChecked())
                        pr+=10;
                    rate.setText(String.valueOf(pr));
                    break;
            }
        }
    }

    private class  CheckBoxEvents implements CompoundButton.OnCheckedChangeListener{

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            double currentPrice=Double.parseDouble(rate.getText().toString());
            switch(buttonView.getId()){
                case R.id.cbBikeRake:
                    if(buttonView.isChecked())
                        currentPrice+=10;
                    else
                        currentPrice-=10;
                    break;
                case R.id.cbChildSeat:
                    if(buttonView.isChecked())
                        currentPrice+=7;
                    else
                        currentPrice-=7;
                    break;
                case R.id.cbNevigator:
                    if(buttonView.isChecked())
                        currentPrice+=5;
                    else
                        currentPrice-=5;
                    break;
            }
            rate.setText(String.format("%.2f",currentPrice));
        }
    }
    // this method to fill temp list of cars upon the passed model name
    //so we will call this method every time the user change cars
    public static void fillTemp(String carName){
        for(Car dsh:carlist)
            if(dsh.getCar().equals(carName))
                temp.add(dsh.getName());
    }

    //this method finds and return the dish object upon the brand name
    public static Car getCarObject(String modelName){
        for(Car dsh:carlist)
            if(dsh.getName().equals(modelName))
                return dsh;
        return null;
    }

    //fill all the data
    public static void fillData(){
    carlist.add(new Car(Cars[0],"Aventador",110.25,4.2,"l1"));
    carlist.add(new Car(Cars[0],"Huracan",95.21,5.3,"l2"));
    carlist.add(new Car(Cars[0],"Sian",115.00,3.3,"l3"));
    carlist.add(new Car(Cars[1],"Cullinan",88.02,5.2,"r1"));
    carlist.add(new Car(Cars[1],"Ghost",78.3,3.5,"r2"));
    carlist.add(new Car(Cars[1],"Dawn",90.15,3.2,"r3"));
    carlist.add(new Car(Cars[2],"Roadster",85,6.2,"b1"));
    carlist.add(new Car(Cars[2],"Coupe",88.23,5.4,"b2"));
    carlist.add(new Car(Cars[2],"Drive Sedan",90.88,3.9,"b3"));
    carlist.add(new Car(Cars[3],"Cabriolet",77.23,6.3,"m1"));
    carlist.add(new Car(Cars[3],"G-Class",75.12,7.2,"m2"));
    carlist.add(new Car(Cars[3],"Benz",70.2,7.5,"m3"));
    }

    //
    public void clearChoices(){
        less.setChecked(false);
        medium.setChecked(false);
        high.setChecked(false);
        navigator.setChecked(false);
        childSeat.setChecked(false);
        bikeRake.setChecked(false);

    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}