package com.example.carrental;

public class Car {
    private String car;
    private String name;
    private double rate;
    private double millage;
    private String img;

    public Car(String car, String name, double rate, double millage, String img) {
        this.car = car;
        this.name = name;
        this.rate = rate;
        this.millage = millage;
        this.img = img;
    }

    public String getCar() {
        return car;
    }

    public String getName() {
        return name;
    }

    public double getRate() {
        return rate;
    }

    public double getMillage() {
        return millage;
    }

    public String getImg() {
        return img;
    }
}
